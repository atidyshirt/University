<template>
    <form action="http://localhost:3000/api/login" method="POST" class='loginPage'>
        <ul>
            <h1>Login Page</h1>
            <li><input type="email" name="email" id="email" placeholder="Email" maxlength="50" required/></li>
            <li><input type="password" name="password" id="password" placeholder="Password" minlength="8" maxlength="50" required/></li>
            <li><input type="submit" value="Log In"></li>
            <li><button type="button" v-on:click="SignUp()">Sign Up</button></li>
        </ul>
    </form>
</template>

<script>
export default {
    name: 'loginPage',
    components: {

    },

    methods: {
        SignUp() {
            this.$router.push('/SignUp')
        }
    }

}
</script>

<style scoped>
    loginPage {
        width: 500px;
        border: 1px solid #CCCCCC;
        background-color: #FFFFFF;
        margin: auto;
        margin-top: 300px;
        padding: 20px;
    }
    ul {
        text-align: center;
        width: 500px;
        border: 2px solid #282828;
        margin: auto;
        padding: 30px;
        list-style-type: none;
    }
    input {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
    }

    input[type=submit] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
    }


    button {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
    }

</style>
