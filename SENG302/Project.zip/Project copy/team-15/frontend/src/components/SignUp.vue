<template>
    <form action="http://localhost:3000/api/users" method="post" class="SignUpPage">
        <ul>
            <h1>Sign Up</h1>
            <li><input type="email" name="email" id="email" placeholder="Email" maxlength="50" required/></li>
            <li><input type="password" name="password" id="password" placeholder="Password" minlength="8" maxlength="50" required/></li>
            <li><input type="text" name="firstName" id="firstName" placeholder="First name" maxlength="30" required/></li>
            <li><input type="text" name="middleName" id="middleName" placeholder="Middle name (optional)" maxlength="30"/></li>
            <li><input type="text" name="lastName" id="lastName" placeholder="Last name" maxlength="30" required/></li>
            <li><input type="text" name="nickName" id="nickName" placeholder="Nickname (optional)" maxlength="30"/></li>
            <li><input type="date" name="dateOfBirth" id="dateOfBirth" placeholder="Date of birth" required/></li>
            <li><input type="text" name="homeAddress" id="homeAddress" placeholder="Address" maxlength="200" required/></li>
            <li><input type="tel" name="phoneNumber" id="phoneNumber" placeholder="Phone number" minlength="10" maxlength="10" required/></li>
            <li><input type="text" name="bio" id="bio" placeholder="Bio" maxlength="500" required/></li>
            <li><input type="submit" value="Register"/></li>
            <h4>{{ label }}</h4>
        </ul>
    </form>
</template>

<script>
export default {
    name: 'signUpPage',
    components: {

    },
    methods: {

    }
}
</script>

<style scoped>
    signUpPage {
        width: 500px;
        border: 1px solid #CCCCCC;
        background-color: #FFFFFF;
        margin: auto;
        margin-top: 300px;
        padding: 20px;
    }
    ul {
        text-align: center;
        width: 500px;
        border: 2px solid #282828;
        margin: auto;
        padding: 30px;
        list-style-type: none;
    }
    input {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
    }
</style>