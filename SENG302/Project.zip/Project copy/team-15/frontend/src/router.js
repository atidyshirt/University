import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from './components/Login.vue'
import SignUp from './components/SignUp.vue'

Vue.use(VueRouter)

export const router = new VueRouter({
    hashbang: false,
    mode: "history",
    routes: [
        { path: "/login", component: Login },
        { path: "/signUp", component: SignUp },
    ]
})