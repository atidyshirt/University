<template>
  <div id="app">
    <router-view></router-view>
    <footer class="info">

    </footer>
  </div>
</template>

<script>
// import Students from "./components/Students";
// Vue app instance
export default {
  name: 'app'
  
}
// it is declared as a reusable component in this case.
// For global instance https://vuejs.org/v2/guide/instance.html
// For comparison: https://stackoverflow.com/questions/48727863/vue-export-default-vs-new-vue
    // list your components here to register them (located under 'components' folder)
    // https://vuejs.org/v2/guide/components-registration.html
  //  Students,
  // app initial state
  // https://vuejs.org/v2/guide/instance.html#Data-and-Methods
</script>

<style>
[v-cloak] {
  display: none;
}
</style>